# retrieval_model.py (Deep Learning Two-Tower Retrieval - FIXED)

import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Embedding, Flatten, Concatenate
from sklearn.preprocessing import MultiLabelBinarizer, LabelEncoder # ADD LabelEncoder
import joblib
from data import ROLES_DATA, MASTER_SKILL_LIST

# --- 1. DATA PREPARATION FOR DEEP LEARNING ---

def prepare_deep_learning_data():
    """
    Creates necessary vocabulary and the training target (User-Role interactions).
    FIXED: Zero-indexes the User IDs.
    """
    roles_df = pd.DataFrame(ROLES_DATA)
    
    # 1a. Skill Binarizer setup (Role Tower Input)
    mlb = MultiLabelBinarizer()
    mlb.fit([MASTER_SKILL_LIST]) 
    num_skills = len(mlb.classes_)
    
    # 1b. Interaction Data (Same as before)
    USER_INTERACTIONS = [
        (101, 'Data Analyst', 1.0),
        (101, 'BI Developer', 1.0),
        (101, 'ML Engineer', 0.0),

        (102, 'Product Manager', 1.0),
        (102, 'Data Analyst', 0.0),
    ]

    interaction_data = pd.DataFrame(USER_INTERACTIONS, 
                                    columns=['user_id', 'role_title', 'target_score'])
    
    # --- FIX: ZERO-INDEXING USER IDs ---
    # Convert large IDs (101, 102) to small sequential indices (0, 1)
    user_encoder = LabelEncoder()
    interaction_data['user_index'] = user_encoder.fit_transform(interaction_data['user_id'])
    
    # The number of users is now correctly calculated from the indices
    num_users = len(user_encoder.classes_)
    
    # Merge skills and get inputs
    interaction_data = pd.merge(interaction_data, roles_df[['title', 'required_skills']], 
                                left_on='role_title', right_on='title', how='left')

    role_features_input = mlb.transform(interaction_data['required_skills'])
    
    # Use the new, zero-indexed user IDs for the model input
    user_index_input = interaction_data['user_index'].values
    
    targets = (interaction_data['target_score'] > 0.5).astype(np.float32).values
    
    # We save the user_encoder for live predictions later!
    joblib.dump(user_encoder, 'retrieval_user_encoder.joblib')
    
    return user_index_input, role_features_input, targets, num_skills, num_users, mlb

# --- 2. THE TWO-TOWER ARCHITECTURE ---

def build_two_tower_model(num_skills, num_users, embedding_dim=32):
    """Defines the Deep Learning model architecture."""
    
    # 2a. USER TOWER: input_dim is now correctly set to the number of unique user INDICES
    user_input = Input(shape=(1,), name='user_input')
    user_embedding = Embedding(input_dim=num_users, output_dim=embedding_dim, 
                               input_length=1, name='user_embedding_layer')(user_input)
    user_vector = Flatten(name='user_vector_output')(user_embedding)

    # 2b. ROLE TOWER (Inputs Role Skills)
    role_input = Input(shape=(num_skills,), name='role_input')
    role_dense = Dense(64, activation='relu')(role_input)
    role_dense = Dense(embedding_dim, activation='relu', name='role_vector_output')(role_dense)
    role_vector = role_dense

    # 2c. JOINT MODEL (For Training)
    dot_product = tf.keras.layers.Dot(axes=1)([user_vector, role_vector])
    
    model = Model(inputs=[user_input, role_input], outputs=dot_product)
    model.compile(optimizer='adam', loss='mse')
    
    return model

# --- 3. TRAINING AND SAVING ---

def train_and_save_retrieval_model():
    user_index_input, role_features_input, targets, num_skills, num_users, mlb = prepare_deep_learning_data()
    
    model = build_two_tower_model(num_skills, num_users)
    
    model.fit(
        {'user_input': user_index_input, 'role_input': role_features_input}, 
        targets, 
        epochs=10, 
        batch_size=32, 
        verbose=0
    )
    print("✅ Deep Learning Two-Tower Model trained successfully.")
    
    # Save the full model and the MultiLabelBinarizer
    model.save('retrieval_two_tower_model.keras')
    joblib.dump(mlb, 'retrieval_mlb.joblib')
    print("✅ Two-Tower Model and Binarizer saved.")

if __name__ == '__main__':
    train_and_save_retrieval_model()
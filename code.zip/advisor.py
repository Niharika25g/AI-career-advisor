# advisor.py (FINAL, CORRECTED, AND ORGANIZED VERSION)
# advisor.py (Imports Section Correction)
import random  
import logging
import pandas as pd
# --- ADD THIS LINE BACK ---
from sklearn.feature_extraction.text import TfidfVectorizer 
from sklearn.metrics.pairwise import cosine_similarity
# -------------------------
from xgboost import XGBClassifier
import joblib 
import numpy as np
import tensorflow as tf 
from tensorflow.keras.models import load_model
from data import ROLES_DATA, COURSES_DATA, MASTER_SKILL_LIST


# Setup basic logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- 1. PREPROCESSING & MODEL SETUP ---

# 1a, 1b: Convert Role Data to a DataFrame and skill list to a single string
roles_df = pd.DataFrame(ROLES_DATA)
roles_df['skills_text'] = roles_df['required_skills'].apply(lambda x: ' '.join(x))

# 1c: Initialize and Fit the TfidfVectorizer
tfidf_vectorizer = TfidfVectorizer(
    vocabulary=MASTER_SKILL_LIST,
    token_pattern=r'\b\w+\b'
)
role_skills_matrix = tfidf_vectorizer.fit_transform(roles_df['skills_text'])


# --- 1D. MODEL TRAINING FUNCTION ---

def train_and_save_model():
    """Trains the XGBoost model using the synthetic data."""
    try:
        df_train = pd.read_csv('training_features.csv') 
    except FileNotFoundError:
        logging.error("ERROR: training_features.csv not found. Please run train_data.py first!")
        return None

    # This MUST match the feature list created in train_data.py
    X = df_train[['similarity_score', 'skill_gap_count', 'goal_alignment', 
                  'domain_alignment', 'learning_pace_score', 'time_since_most_used_skill', 
                  'market_demand_score']] 
    y = df_train['target_relevance']
    
    model = XGBClassifier(
        objective='binary:logistic', 
        use_label_encoder=False, 
        eval_metric='logloss',
        random_state=42
    )
    model.fit(X, (y >= 0.7).astype(int)) 

    joblib.dump(model, 'ranking_model.joblib')
    logging.info("✅ XGBoost Ranking model trained and saved as ranking_model.joblib")
    
    return model


# --- 1E. FEATURE STORE LOADING ---

try:
    USER_STORE = pd.read_csv('feature_store_user.csv').set_index('user_id')
    ROLE_STORE = pd.read_csv('feature_store_role_market.csv').set_index('role_title')
    logging.info("✅ Feature Store loaded successfully.")
except Exception as e:
    logging.error(f"FATAL ERROR: Could not load Feature Store CSVs: {e}")
    USER_STORE = None
    ROLE_STORE = None


# --- 1F. MODEL LOADING ---

try:
    RANKING_MODEL = joblib.load('ranking_model.joblib')
    logging.info("✅ Loaded trained ranking_model.joblib")
except FileNotFoundError:
    logging.warning("⚠️ Ranking model not found. Training model now (Requires training_features.csv)...")
    RANKING_MODEL = train_and_save_model()


# --- 1G. MLOPS DRIFT CHECK FUNCTION ---

def simulate_drift_check():
    """Simulates a periodic MLOps check for data/model health."""
    logging.info("--- MLOps Health Check Running ---")
    
    if not MASTER_SKILL_LIST:
        logging.critical("Data Integrity Error: MASTER_SKILL_LIST is empty. System halted.")
        return False

    current_python_usage = 0.5 
    if current_python_usage < 0.2:
        logging.warning(
            "DATA DRIFT ALERT: Python skill usage dropped below 20%. "
        )
        return True
    
    logging.info("MLOps Status: System health looks nominal. No major drift detected.")
    return True

# Run MLOps check on startup
if RANKING_MODEL:
    simulate_drift_check()

# --- 1H. FEATURE IMPORTANCE ANALYSIS (XGBoost) ---
if RANKING_MODEL and hasattr(RANKING_MODEL, 'feature_importances_'):
    logging.info("✨ Learned Feature Importances (XGBoost):")
    # Using the correct 7 feature names for logging
    feature_names = ['Similarity Score', 'Skill Gap Count', 'Goal Alignment', 
                     'Domain Alignment', 'Learning Pace Score', 
                     'Time Since Used Skill', 'Market Demand Score'] 
    importances = RANKING_MODEL.feature_importances_
    
    for name, importance in zip(feature_names, importances):
        logging.info(f"  {name}: {importance:.3f}")

# --- 2. CORE RECOMMENDATION FUNCTION ---

# Helper function for safe feature store lookup
def safe_market_lookup(title, store):
    """Safely looks up a numeric market score with robust fallback."""
    try:
        # Look up the numeric score saved in the feature store
        score = store.loc[title, 'market_demand_score']
        return float(score)
    except Exception:
        # Default value if the role title is not found or data is bad
        return 0.5

def recommend_career(user_skills: list, user_career_goal: str, user_id: int = 101, top_n: int = 5):
    """
    Recommends career paths using the full 7-feature set derived from the Feature Store.
    """
    if not RANKING_MODEL or USER_STORE is None or ROLE_STORE is None:
        logging.error("Model or Feature Store not available.")
        return []

    user_skills_text = ' '.join(user_skills)
    
    # --- Feature Retrieval ---
    user_skills_matrix = tfidf_vectorizer.transform([user_skills_text])
    similarity_scores = cosine_similarity(user_skills_matrix, role_skills_matrix)[0]
    roles_df['similarity_score'] = similarity_scores
    
    # Get pre-calculated user features (Temporal Features)
    user_id_str = str(user_id)
    try:
        if user_id in USER_STORE.index:
            user_temporal_features = USER_STORE.loc[user_id]
        elif user_id_str in USER_STORE.index:
            user_temporal_features = USER_STORE.loc[user_id_str]
        else:
            raise KeyError("User ID not found.") # Triggers the except block below

        user_pace = float(user_temporal_features['learning_pace_score'])
        user_decay = float(user_temporal_features['time_since_most_used_skill'])
    except:
        logging.warning(f"User ID {user_id} not found in Feature Store. Using cold start defaults.")
        user_pace, user_decay = 0.5, 6.0 

    # Calculate base features (Skill Gap)
    role_matrix_array = role_skills_matrix.toarray()
    user_matrix_array = user_skills_matrix.toarray()
    
    user_has_indices = user_matrix_array.nonzero()[1]
    user_binary_vector = [1 if i in user_has_indices else 0 for i in range(len(MASTER_SKILL_LIST))]

    role_binary_matrix = (role_matrix_array > 0).astype(int) 
    missing_skills_matrix = role_binary_matrix - user_binary_vector
    missing_skills_matrix[missing_skills_matrix < 0] = 0 
    missing_skills_count = missing_skills_matrix.sum(axis=1)
    
    # --- 2e. RANKING: Prepare all 7 Features for XGBoost ---
    
    features_for_prediction = pd.DataFrame({
        'similarity_score': roles_df['similarity_score'],
        'skill_gap_count': missing_skills_count,
        'goal_alignment': roles_df['career_path'].apply(
             lambda x: 1.0 if x.lower() == user_career_goal.lower() else 0.0
        ), 
        'domain_alignment': roles_df['domain_tag'].apply( 
             lambda tag: 1.0 if tag.lower() == user_career_goal.lower() else 0.0
        ), 
        'learning_pace_score': user_pace,
        'time_since_most_used_skill': user_decay,
        
        # --- FINAL FIX: Use the safe lookup and correct name ---
        'market_demand_score': roles_df['title'].apply(
            lambda title: safe_market_lookup(title, ROLE_STORE) 
        ).values
    })
    
    # Predict the probability of a "Good Fit"
    fit_probabilities = RANKING_MODEL.predict_proba(features_for_prediction)[:, 1]
    roles_df['final_fit_score'] = fit_probabilities
    
    # Sort and select the top N roles
    roles_df['final_fit_score'] = roles_df['final_fit_score'].fillna(0.0)
    ranked_roles = roles_df.sort_values(by='final_fit_score', ascending=False).head(top_n).to_dict('records')
    
    # --- 2f. LLM Explanation and Final Results Compilation ---
    final_results = []
    
    for role in ranked_roles:
        role_required = set(role['required_skills'])
        user_skills_set = set(user_skills)
        missing_skills = list(role_required - user_skills_set)
        matched_skills = list(role_required & user_skills_set)
        learning_recommendations = find_learning_paths(missing_skills)

        # LLM Explanation Logic (Rule-Based)
        explanation_parts = []
        if matched_skills:
            top_matched = ', '.join(matched_skills[:3])
            explanation_parts.append(
                f"Your existing skills like **{top_matched}** provide a strong foundation for this role."
            )
        if missing_skills:
            top_missing = ', '.join(missing_skills[:2])
            explanation_parts.append(
                f"To succeed, we suggest focusing on core gaps such as **{top_missing}**."
            )
        if role['career_path'].lower() == user_career_goal.lower():
            explanation_parts.append(
                f"This role aligns with your goal of entering the **{user_career_goal.title()}** career path."
            )
        llm_explanation = ' '.join(explanation_parts)

        result = {
            'role_title': role['title'],
            'fit_score': round(role['final_fit_score'], 3),
            'explanation': llm_explanation,
            'top_skill_gaps': missing_skills,
            'learning_path_courses': learning_recommendations
        }
        final_results.append(result)

    # --- 2g. MLOps: Log the Request and Prediction (FINAL PLACEMENT) ---
    try:
        top_role = final_results[0]['role_title']
        top_score = final_results[0]['fit_score']
        
        logging.info(
            f"REQUEST | Goal: {user_career_goal} | Skills: {len(user_skills)} | "
            f"Prediction: {top_role} | Score: {top_score:.3f}"
        )
    except Exception as e:
        logging.error(f"Failed to log prediction: {e}")

    return final_results


# advisor.py (AI Coach Logic)

def get_ai_coach_response(user_skills, top_role, question):
    """GenAI Agent: Features an 'Assistant Switch' for irrelevant queries."""
    q_lower = question.lower().strip()
    
    # 1. Define 'Career' topics
    career_topics = ['job', 'interview', 'salary', 'career', 'skill', 'learn', 'work', 'hire', 'role', 'resume']
    
    # 2. Check if the question is actually about career/roles
    is_career_query = any(topic in q_lower for topic in career_topics)

    # MODE A: CAREER STRATEGIST (Elaborate & Role-Specific)
    if is_career_query:
        thought = f"Thinking: Career intent detected. Tailoring strategy for {top_role}."
        
        if "interview" in q_lower:
            response = (
                f"### 🎯 Interview Strategy for {top_role}\n"
                f"Since you are proficient in **{', '.join(user_skills[:2])}**, interviewers will test how you apply these to {top_role} business problems.\n\n"
                f"**Key Advice:**\n"
                f"* **Master the Tools:** Be ready to explain your specific workflow in {user_skills[0]}.\n"
                f"* **Soft Skills:** Focus on how you communicate technical data to non-technical teams.\n"
                f"* **The Gap:** Review the 'Critical Gaps' in your dashboard; these are your most likely interview weaknesses."
            )
        else:
            response = (
                f"### 📈 Career Roadmap: {top_role}\n"
                f"Becoming a **{top_role}** is a great move. With your background in {user_skills[0]}, you have a solid foundation. "
                f"To reach the next level, I suggest building a portfolio project that specifically uses the skills you are currently missing."
            )

    # MODE B: GENERAL ASSISTANT (For 'Irrelevant' Questions)
    else:
        thought = "Thinking: Irrelevant query detected. Switching to General Assistant mode."
        response = (
            f"**Assistant:** I noticed you're asking about something outside of our career strategy! "
            f"While I'm usually focused on helping you become a **{top_role}**, I can help with this too.\n\n"
            f"Regarding **'{question}'**: Since I am a simulated agent, I recommend checking a general search engine or ChatGPT for real-time news. "
            f"Is there anything specific to your **{top_role}** journey you'd like to get back to?"
        )

    # Return with the double newline for your JavaScript splitting
    return f"{thought}\n\n{response}"
# --- 3. LEARNING PATH UTILITY FUNCTION ---

def find_learning_paths(missing_skills: list):
    """Maps missing skills to relevant courses."""
    if not missing_skills:
        return []

    recommended_courses = []
    
    for course in COURSES_DATA:
        course_teaches_skills = set(course['skills_taught'])
        overlap = list(set(missing_skills) & course_teaches_skills)
        
        if overlap:
            recommended_courses.append({
                'title': course['title'],
                'provider': course['provider'],
                'teaches_skills': overlap
            })
            
    unique_courses = []
    seen_titles = set()
    for course in recommended_courses:
        if course['title'] not in seen_titles:
            unique_courses.append(course)
            seen_titles.add(course['title'])
            
    return unique_courses


def get_interview_question(user_skills, top_role_title):
    """GenAI Agent: Picks a different technical question each time."""
    
    # 1. A library of questions to prevent repetition
    question_bank = [
        f"As a candidate for {top_role_title}, how do you ensure the scalability of a system using {user_skills[0] if user_skills else 'your primary tools'}?",
        f"Explain a time you had to debug a complex issue in a production environment related to {top_role_title}.",
        f"What are the top three security considerations you prioritize when working with {user_skills[1] if len(user_skills) > 1 else 'modern frameworks'}?",
        f"How would you explain the technical limitations of your current stack to a non-technical stakeholder?"
    ]
    
    # 2. Randomly select a question
    selected_question = random.choice(question_bank)
    
    thought = f"Thinking: Randomly selecting from competency bank for {top_role_title}."
    return f"{thought}\n\n**Interviewer:** '{selected_question}'"

def evaluate_interview_answer(question, answer, role):
    """GenAI Agent: Evaluates answer and provides a 'Cheat Sheet' ideal response."""
    thought = f"Thinking: Assessing technical depth and generating an ideal response for {role}."
    
    clean_answer = answer.lower().strip()
    word_count = len(clean_answer.split())
    
    # 1. Strict Scoring Logic
    if "don't know" in clean_answer or word_count < 5:
        score = 1
        feedback = "**Feedback:** Too brief or lack of knowledge shown."
    elif not any(word in clean_answer for word in ['data', 'process', 'tool', 'workflow']):
        score = 4
        feedback = "**Feedback:** You need more technical detail."
    else:
        score = 8
        feedback = "**Feedback:** Great job! You covered the core requirements."

    # 2. The Cheat Sheet (Ideal Answer)
    ideal_answer = f"**Agent Cheat Sheet:** For a {role} role, a perfect answer should mention: 1) Specific tools (SQL/PowerBI), 2) The STAR method (Situation, Task, Action, Result), and 3) Data-driven outcomes."

    return f"{thought}\n\n**Score: {score}/10**\n{feedback}\n\n{ideal_answer}"
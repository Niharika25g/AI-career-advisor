# data.py

# --- A. Master List of Skills (Used to ensure consistent spelling) ---
MASTER_SKILL_LIST = [
    'sql', 'python', 'statistics', 'data visualization', 'deep learning', 
    'cloud computing', 'mlops', 'business acumen', 'project management',
    'excel', 'communication', 'r', 'javascript', 'tableau', 'powerbi'
]


# --- B. Role Definitions (What the job requires) ---
# NOTE: All 'required_skills' are LOWERCASED for consistency.
ROLES_DATA = [
    {
        'id': 1,
        'title': 'Data Analyst',
        'required_skills': ['sql', 'python', 'statistics', 'data visualization', 'excel'],
        'career_path': 'Data Science',
        'domain_tag': 'Data Science & Analytics', # NEW
        'difficulty_score': 3 
    },
    {
        'id': 2,
        'title': 'ML Engineer',
        'required_skills': ['python', 'deep learning', 'cloud computing', 'mlops', 'statistics'],
        'career_path': 'AI/ML',
        'domain_tag': 'AI & Machine Learning', # NEW
        'difficulty_score': 5
    },
    {
        'id': 3,
        'title': 'Product Manager',
        'required_skills': ['communication', 'business acumen', 'project management', 'data visualization'],
        'career_path': 'Management',
        'domain_tag': 'Business & Strategy', # NEW
        'difficulty_score': 4
    },
    {
        'id': 4,
        'title': 'BI Developer',
        'required_skills': ['sql', 'tableau', 'powerbi', 'data visualization', 'excel'],
        'career_path': 'Data Science',
        'domain_tag': 'Data Science & Analytics', # NEW
        'difficulty_score': 3
    }
]


# --- C. Learning Resource Definitions ---
COURSES_DATA = [
    {
        'title': 'Complete SQL Masterclass',
        'skills_taught': ['sql', 'database management'],
        'provider': 'Udemy'
    },
    {
        'title': 'Python for Everybody',
        'skills_taught': ['python', 'basic programming'],
        'provider': 'Coursera'
    },
    {
        'title': 'Deep Learning Specialization',
        'skills_taught': ['deep learning', 'tensorflow'],
        'provider': 'Coursera'
    }
]
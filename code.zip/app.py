# app.py (FINAL WORKING VERSION)
from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import json
import os
# Ensure you have imported both the core recommender and the new coach function
from advisor import recommend_career, get_ai_coach_response, get_interview_question, evaluate_interview_answer

# --- Configuration & Initialization ---
app = Flask(__name__)
app.secret_key = 'your_strong_secret_key_for_session' # !! CRITICAL for sessions !!

USER_DB_PATH = 'users_db.json'

# --- Utility Functions for User Data ---

def load_users():
    """Loads user data from the JSON file."""
    if not os.path.exists(USER_DB_PATH):
        return {}
    try:
        with open(USER_DB_PATH, 'r') as f:
            return json.load(f)
    except json.JSONDecodeError:
        return {}

def save_users(users):
    """Saves user data back to the JSON file."""
    with open(USER_DB_PATH, 'w') as f:
        json.dump(users, f, indent=4)
# --- GenAI Utility: Synthetic Data Generation ---
def generate_synthetic_profile(interest_area):
    """
    Simulates a GenAI call to create a 'starter' profile for 
    users with no experience (Cold Start problem).
    """
    synthetic_library = {
        "Data Science & Analytics": ["Excel", "Basic Statistics", "Problem Solving"],
        "AI & Machine Learning": ["Python", "Mathematics", "Logic"],
        "Management": ["Communication", "Teamwork", "Organization"]
    }
    # Returns simulated skills based on interest, or a general set if not found
    return synthetic_library.get(interest_area, ["Basic Communication", "Digital Literacy"])
# --- Routes: Authentication ---

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    """Handles user registration."""
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        users = load_users()
        
        if not username or not password:
            return render_template('signup.html', error='Username and password are required.')
        
        if username in users:
            return render_template('signup.html', error='Username already exists.')
        
        # Hash the password securely and assign a unique user_id
        users[username] = {
            'password_hash': generate_password_hash(password), 
            'user_id': len(users) + 101
        }
        save_users(users)
        return redirect(url_for('login', message='Account created successfully!'))
    
    return render_template('signup.html')

@app.route('/', methods=['GET', 'POST'])
@app.route('/login', methods=['GET', 'POST'])
def login():
    """Handles user login and is the default entry point."""
    if 'user_id' in session:
        return redirect(url_for('advisor'))
    
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        users = load_users()
        
        if username in users and check_password_hash(users[username]['password_hash'], password):
            # Login success: store user_id in session
            session['user_id'] = users[username]['user_id']
            session['username'] = username
            return redirect(url_for('advisor'))
        else:
            return render_template('login.html', error='Invalid username or password.')
            
    return render_template('login.html', message=request.args.get('message'))

@app.route('/logout')
def logout():
    """Logs the user out and clears the session."""
    session.pop('user_id', None)
    session.pop('username', None)
    return redirect(url_for('login', message='You have been logged out.'))

# --- Routes: Core Application ---

@app.route('/advisor')
def advisor():
    """The main career advisor interface."""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Pass user info to the HTML template
    return render_template('advisor.html', 
                           username=session['username'], 
                           user_id=session['user_id'])


# --- Routes: ML API Endpoint (Secured) ---

# --- Routes: ML API Endpoint (Secured) ---

@app.route('/recommend_api', methods=['POST'])
def recommend_api():
    """Secured API endpoint to get career recommendations."""
    if 'user_id' not in session:
        return jsonify({"status": "error", "error": "Unauthorized"}), 401
    
    try:
        data = request.json
        user_skills = data.get('user_skills', [])
        user_goal = data.get('user_goal', '')

        # --- GEN AI LOGIC: Handle empty skills (Cold Start) ---
        # If the user provides no skills, we use GenAI to generate a synthetic profile
        if not user_skills or (len(user_skills) == 1 and user_skills[0] == ""):
            print(f"GenAI: Generating synthetic profile for goal: {user_goal}")
            user_skills = generate_synthetic_profile(user_goal)
        
        # --- ML LOGIC: Call the core recommender from advisor.py ---
        # This calls your Two-Tower Retrieval and XGBoost Ranking pipeline
        recommendations = recommend_career(user_skills, user_goal, session['user_id'])
        
        # IMPORTANT: We return 'status': 'success' so advisor.html knows it worked
        return jsonify({
            "status": "success",
            "recommendations": recommendations 
        })
        
    except Exception as e:
        print(f"Error in recommend_api: {e}")
        return jsonify({"status": "error", "error": str(e)}), 500
# --- Routes: AI COACH API Endpoint (New) ---

@app.route('/coach_api', methods=['POST'])
def get_coach_response_api():
    """Endpoint for interactive Q&A with the AI Coach."""
    if 'user_id' not in session:
        return jsonify({"error": "Unauthorized. Please log in."}), 401
    
    try:
        data = request.get_json()
        # Ensure these keys match what your JavaScript 'fetch' sends
        user_skills = data.get('user_skills', []) 
        top_role = data.get('top_role', 'Unknown Role')
        question = data.get('question', '')
    except Exception:
        return jsonify({"error": "Invalid request data."}), 400

    # Call the RAG-based AI Coach logic from advisor.py
    try:
        response_text = get_ai_coach_response(user_skills, top_role, question)
        # FIX: Change 'response' to 'answer' to match advisor.html JavaScript
        return jsonify({"status": "success", "answer": response_text}) 
    except Exception as e:
        print(f"Error calling AI Coach logic: {e}")
        return jsonify({"error": "Internal error during coaching logic."}), 500
    
@app.route('/interview_api', methods=['POST'])
def interview_api():
    """Endpoint for the Mock Interview Agent."""
    if 'user_id' not in session:
        return jsonify({"error": "Unauthorized"}), 401

    try:
        data = request.get_json()
        user_skills = data.get('user_skills', [])
        top_role = data.get('top_role', '')

        # Generate the question using the advisor logic
        interview_content = get_interview_question(user_skills, top_role)
        
        return jsonify({
            "status": "success", 
            "question": interview_content
        })
    except Exception as e:
        print(f"Interview API Error: {e}")
        return jsonify({"error": "Internal server error"}), 500
    
@app.route('/evaluate_api', methods=['POST'])
def evaluate_api():
    """Endpoint for the Evaluation Agent."""
    if 'user_id' not in session:
        return jsonify({"error": "Unauthorized"}), 401
    
    try:
        data = request.get_json()
        question = data.get('question', '')
        answer = data.get('answer', '')
        role = data.get('top_role', '')

        from advisor import evaluate_interview_answer
        evaluation = evaluate_interview_answer(question, answer, role)
        
        return jsonify({"status": "success", "evaluation": evaluation})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    # Ensure users_db.json exists
    if not os.path.exists(USER_DB_PATH):
        save_users({})
    
    app.run(debug=True)
    

# train-data.py (FINAL CORRECTED VERSION - Expanded Data for Learning)
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from data import ROLES_DATA, MASTER_SKILL_LIST
import numpy as np
import os
from xgboost import XGBClassifier
import joblib 

# --- Helpers ---
def n_title(s: str) -> str: return str(s).strip().casefold()
def n_skill(s: str) -> str: return str(s).strip().lower()
def join_skills(sk_list) -> str: return " ".join(n_skill(s) for s in sk_list)

# --- Prepare roles DF & TF-IDF ---
roles_df = pd.DataFrame(ROLES_DATA)
roles_df["skills_text"] = roles_df["required_skills"].apply(join_skills)
vocab_lower = [n_skill(s) for s in MASTER_SKILL_LIST]
tfidf_vectorizer = TfidfVectorizer(
    vocabulary=vocab_lower, lowercase=True
).fit(roles_df['skills_text'])
role_skills_matrix = tfidf_vectorizer.transform(roles_df['skills_text'])

# --- Load Feature Stores (Ensure feature_pipeline.py has run) ---
USER_STORE_CSV = 'feature_store_user.csv'
ROLE_MARKET_CSV = 'feature_store_role_market.csv'

if not all([os.path.exists(USER_STORE_CSV), os.path.exists(ROLE_MARKET_CSV)]):
    raise FileNotFoundError("Feature Store CSVs not found. Run feature_pipeline.py first.")

user_features_store = pd.read_csv(USER_STORE_CSV)
role_market_store = pd.read_csv(ROLE_MARKET_CSV).set_index('role_title')


# --- Synthetic users (EXPANDED FOR DATA VARIANCE) ---
# train-data.py (EXPANDED SYNTHETIC USERS)

SYNTHETIC_USERS = [
    {
        'user_id': 101, 'skills': ['sql', 'python', 'excel'], 
        'goal': 'Data Science & Analytics', 
        'targets': {'Data Analyst': 1.0, 'ML Engineer': 0.2, 'Product Manager': 0.5, 'BI Developer': 0.9} 
    },
    {
        'user_id': 102, 'skills': ['communication', 'project management'], 
        'goal': 'Management', 
        'targets': {'Data Analyst': 0.1, 'ML Engineer': 0.0, 'Product Manager': 1.0, 'BI Developer': 0.3}
    },
    {
        'user_id': 103, 'skills': ['r', 'statistics', 'communication'], 
        'goal': 'Data Science & Analytics', 
        'targets': {'Data Analyst': 0.85, 'ML Engineer': 0.1, 'Product Manager': 0.4, 'BI Developer': 0.95} 
    },
    {
        'user_id': 104, 'skills': ['javascript', 'cloud computing', 'python'], 
        'goal': 'AI & Machine Learning', 
        'targets': {'Data Analyst': 0.3, 'ML Engineer': 0.75, 'Product Manager': 0.5, 'BI Developer': 0.2} 
    },
    # --- ADDED USERS FOR VARIANCE ---
    {
        'user_id': 105, 'skills': ['sql', 'communication', 'tableau'], 
        'goal': 'Data Science & Analytics', 
        'targets': {'Data Analyst': 0.6, 'ML Engineer': 0.1, 'Product Manager': 0.7, 'BI Developer': 0.8}
    },
    {
        'user_id': 106, 'skills': ['python', 'deep learning', 'statistics'], 
        'goal': 'AI & Machine Learning', 
        'targets': {'Data Analyst': 0.7, 'ML Engineer': 1.0, 'Product Manager': 0.5, 'BI Developer': 0.4}
    },
    {
        'user_id': 107, 'skills': ['project management', 'excel'], 
        'goal': 'Management', 
        'targets': {'Data Analyst': 0.3, 'ML Engineer': 0.1, 'Product Manager': 0.9, 'BI Developer': 0.6}
    },
    {
        'user_id': 108, 'skills': ['sql', 'powerbi', 'data visualization'], 
        'goal': 'Data Science', 
        'targets': {'Data Analyst': 0.75, 'ML Engineer': 0.1, 'Product Manager': 0.4, 'BI Developer': 0.9}
    },
]

# -----------------------------
# Build training rows
# -----------------------------
training_rows = [] 

required_skills_count = roles_df['required_skills'].apply(len).to_numpy()

for user in SYNTHETIC_USERS:
    uf = user_features_store[user_features_store['user_id'] == user['user_id']]
    
    # Feature Store Lookup Safety
    if uf.empty or 'learning_pace_score' not in uf.columns:
        learning_pace_score, time_since_most_used_skill = 0.5, 180.0
    else:
        row = uf.iloc[0]
        learning_pace_score = float(row["learning_pace_score"])
        time_since_most_used_skill = float(row["time_since_most_used_skill"])

    user_skills_text = join_skills(user['skills'])
    user_skills_matrix = tfidf_vectorizer.transform([user_skills_text])
    similarity_scores = cosine_similarity(user_skills_matrix, role_skills_matrix)[0]

    for i, role in roles_df.iterrows():
        
        # Base Features
        current_user_skills = set([n_skill(s) for s in user['skills']])
        role_required_skills = set([n_skill(s) for s in role['required_skills']])
        overlap_count = len(current_user_skills & role_required_skills)
        missing_skills_count = len(role_required_skills) - overlap_count
        
        # NOTE: Goal/Domain alignment logic must use casefolded strings for comparison
        goal_alignment = 1.0 if n_title(role['career_path']) == n_title(user['goal']) else 0.0
        domain_alignment = 1.0 if n_title(role['domain_tag']) == n_title(user['goal']) else 0.0

        # Market Demand Feature (Numeric)
        try:
            market_score = float(role_market_store.loc[role['title']]['market_demand_score'])
        except KeyError:
            market_score = 0.5 # Default if role title not in store

        training_rows.append({
            'similarity_score': float(similarity_scores[i]),
            'skill_gap_count': float(missing_skills_count),
            'goal_alignment': goal_alignment,
            'domain_alignment': domain_alignment,
            'learning_pace_score': learning_pace_score,
            'time_since_most_used_skill': time_since_most_used_skill,
            'market_demand_score': market_score, 
            'target_relevance': float(user['targets'].get(role['title'], 0.0))
        })

# --- Save CSV and Train Model ---
df_train = pd.DataFrame(training_rows)
df_train.to_csv('training_features.csv', index=False)
print("✅ training_features.csv created (with 7 numeric features and variance).")

# Define the exact 7 features used for XGBoost
X_features = [
    'similarity_score', 'skill_gap_count', 'goal_alignment', 'domain_alignment',
    'learning_pace_score', 'time_since_most_used_skill', 'market_demand_score'
]
X = df_train[X_features]
y = df_train['target_relevance']

model = XGBClassifier(
    objective='binary:logistic', use_label_encoder=False, eval_metric='logloss', random_state=42
)

# Use the correct fit call (relying on Pandas column names)
model.fit(
    X, 
    (y >= 0.7).astype(int)
) 

joblib.dump(model, 'ranking_model.joblib')
print("✅ XGBoost Ranking model trained and saved successfully.")
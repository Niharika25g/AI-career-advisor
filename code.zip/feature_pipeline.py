# feature_pipeline.py (FINAL CORRECTED VERSION - Processing 8 Users)
import pandas as pd
import numpy as np
from data import ROLES_DATA

# --- Market Feature Generation Helper ---
# Define a simple numeric scale for market trend
MARKET_TREND_MAPPING = {
    'declining': 0.1,
    'stable': 0.5,
    'rising': 1.0,
}

def generate_role_market_features(role_title):
    """Generates market score for a role."""
    # Seed based on role title for consistent, but varied, role features
    np.random.seed(hash(role_title) % 1000) 
    
    base_trend_key = np.random.choice(['rising', 'stable', 'declining'], p=[0.4, 0.4, 0.2])
    base_score = MARKET_TREND_MAPPING[base_trend_key]
    
    final_score = base_score + np.random.uniform(-0.1, 0.1)
    
    return {
        'role_title': role_title,
        'market_demand_score': round(max(0, final_score), 3),
    }

def generate_user_temporal_features(user_id):
    """Simulates user learning pace and skill decay (temporal features)."""
    # Seed based on user ID for consistent user features
    np.random.seed(user_id) 
    
    pace = np.random.uniform(0.5, 3.0) 
    time_decay = np.random.uniform(10, 180) # days
    
    return {
        'user_id': user_id,
        'learning_pace_score': round(pace, 2),
        'time_since_most_used_skill': round(time_decay, 1)
    }

# --- FIX: Expanded list of users to process (101 through 108) ---
def run_feature_pipeline(user_ids_to_process=[101, 102, 103, 104, 105, 106, 107, 108]): 
    
    # --- Generate User Features ---
    user_features = [generate_user_temporal_features(uid) for uid in user_ids_to_process]
    user_features_df = pd.DataFrame(user_features)
    user_features_df.to_csv('feature_store_user.csv', index=False)
    print("✅ User Temporal Features saved to feature_store_user.csv")

    # --- Generate Role Features ---
    role_features = [generate_role_market_features(role['title']) for role in ROLES_DATA]
    role_features_df = pd.DataFrame(role_features)
    role_features_df.to_csv('feature_store_role_market.csv', index=False)
    print("✅ Role Market Features saved to feature_store_role_market.csv")

if __name__ == '__main__':
    run_feature_pipeline()